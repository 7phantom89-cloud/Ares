ARES (runs on the visitor's own computer: no API key, no server)

The whole website is ONE file: index.html

TO PUT IT ONLINE (easiest way, no GitHub needed)
1. Make a new empty folder on your computer and name it "ares".
2. Put index.html inside that folder.
3. Go to app.netlify.com/drop in your browser.
4. Drag the "ares" folder onto the page.
5. Netlify gives you a link. That is your live website.
   If it asks you to sign up, do it (free). Without an account the site can expire.

TO UPDATE A SITE YOU ALREADY PUT ONLINE
Open your site in Netlify, go to its "Deploys" tab, and drag the new "ares" folder onto
the box that says to drop your site folder. The link stays the same.
(If you drop it on app.netlify.com/drop again you get a second, separate site.)

IF YOU DOUBLE-CLICK index.html ON YOUR COMPUTER
The particles, Playground, light/dark button and quick commands all work.
The on-device AI works best from a real web link (the Netlify link), because browsers
treat files opened from your disk more strictly.

TO UNZIP (only if you downloaded the .zip)
- Windows: right-click the .zip file, choose "Extract All...", then click "Extract".
- Mac: double-click the .zip file.

WHAT IS ON THE PAGE
- The 3D particle field (drag it, push or pull it with the pointer).
- A Light / Dark button.
- Playground: five toys (Emitters, Flock, Orbits, Fireworks, Flow).
  In Emitters you can place Jets, Rings, Lines, Spirals, Novas and Comets, and Attractors,
  Repellers, Vortexes, Wind, Turbulence and Sinks. Space pauses, C clears.
- Ares, the AI assistant.

HOW THE AI WORKS
- On your own website, the first real question downloads a small AI model into the
  visitor's browser (about 0.7 GB for "Fast", about 2 GB for "Smarter"). It is saved
  on their device, so later visits start in seconds. Nothing they type is sent anywhere.
- Simple maths ("3+4", "18% of 2,340"), greetings, and particle commands ("show the cube",
  "cycle every 4 seconds", "attract") answer instantly without the model.
- "Fast" is the default. "Smarter" gives better answers but is slower and can make
  the computer lag.
- When this same page is opened inside Claude, it uses Claude instead.

WHAT IT NEEDS
- A laptop or desktop with a recent Chrome or Edge (WebGPU) for the on-device AI.
  Phones and old computers often cannot run it. Everything else works on most devices.

HONEST LIMITS
- The on-device model is small and open, not Claude. It is good for chat, simple writing
  and short code. It is weaker at hard reasoning, long answers and big code.
- Test one full chat on your own computer after you publish.

PLAYGROUND TIP: In Emitters mode, click any emitter or force to select it. A panel appears where you can tune rate, speed, pull/push and more, duplicate it, or delete it (Delete key also works). Drag to move it. The Select tool lets you pick things without placing new ones.
